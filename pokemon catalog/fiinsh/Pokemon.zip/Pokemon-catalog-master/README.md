# Pokemon catalog

W tym repozytorium znajduje się kod drugiego wyzwania przedstawionego publiczności kanału Samuraj Programowania.

## Zapowiedź wyzwania

[W tym miejscu](https://www.youtube.com/watch?v=lAYDGlB9xbs) możesz zobaczyć zapowiedź odcinka w którym będę pokazywał jak zrobić taki katalog, natomiast [tutaj](https://www.youtube.com/watch?v=lAYDGlB9xbs) możesz zobaczyć rozwiązanie tego projektu :)

## Dokumentacja API

[TUTAJ](https://docs.pokemontcg.io/) znajdziesz dokumentację API którego używam w projekcie :)
